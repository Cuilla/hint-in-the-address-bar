// Установка дефолтной подсказки
chrome.omnibox.setDefaultSuggestion({
    description: 'Поиск похожих доменов для: %s'
});

// Обработка изменений ввода
chrome.omnibox.onInputChanged.addListener((text, suggest) => {
    const suggestions = generateSuggestions(text);
    suggest(suggestions);
});

// Обработка выбора
chrome.omnibox.onInputEntered.addListener((text, disposition) => {
    const url = validateDomain(text) || `https://${text}`;
    openUrl(url, disposition);
});

function generateSuggestions(input) {
    // Пример логики для .com/.net/.org вариантов
    return [
        { content: `${input}.com`, description: `${input}.com` },
        { content: `${input}.net`, description: `${input}.net` },
        { content: `${input}.org`, description: `${input}.org` }
    ];
}

function validateDomain(domain) {
    // Добавьте проверку через WHOIS API или локальный словарь
    return /^[\w-]+(\.[a-z]{2,})+$/.test(domain) ? `https://${domain}` : null;
}

function openUrl(url, disposition) {
    switch(disposition) {
        case 'currentTab': 
            chrome.tabs.update({url});
            break;
        case 'newForegroundTab': 
            chrome.tabs.create({url});
            break;
        default:
            chrome.tabs.create({url, active: false});
    }
}

